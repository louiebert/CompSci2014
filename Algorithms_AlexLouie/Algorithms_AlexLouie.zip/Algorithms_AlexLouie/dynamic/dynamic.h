
#ifndef DYNAMIC_H
#define DYNAMIC_H 

// Returns a vector containing the chars comprising the longest commmon subsequence 
//  given two strings.
string Dynamic_Programming_LCS(string review1, string review2);

#endif 